import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import type { DesiredContractTarget, DesiredDeploymentState } from "./deploymentState.js";
export interface DeployerWallet {
    address: string;
    utxos: CardanoTypes.Utxo[];
}
export interface BuiltTransaction {
    cborHex: string;
    estimatedSignedTxSize: number;
    /** UTxO refs consumed as inputs (txHash#index), for excluding from subsequent txs */
    consumedInputs: Set<string>;
}
export declare const resolveDeployerWallet: ({ network, currentSubhandle, userAgent, blockfrostApiKey, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    currentSubhandle: string;
    userAgent: string;
    blockfrostApiKey: string;
    fetchFn?: typeof fetch;
}) => Promise<DeployerWallet>;
export declare const resolveHandleUtxo: ({ network, handleName, userAgent, blockfrostApiKey, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    handleName: string;
    userAgent: string;
    blockfrostApiKey: string;
    fetchFn?: typeof fetch;
}) => Promise<CardanoTypes.Utxo>;
export declare const buildReferenceScriptDeploymentTx: ({ desired, contract, handleName, changeAddress: _changeAddress, spareUtxos: _spareUtxos, nativeScriptCborHex, blockfrostApiKey, userAgent, excludeUtxoRefs, }: {
    desired: DesiredDeploymentState;
    contract: DesiredContractTarget;
    handleName: string;
    changeAddress: string;
    spareUtxos: CardanoTypes.Utxo[];
    nativeScriptCborHex?: string;
    blockfrostApiKey?: string;
    userAgent?: string;
    excludeUtxoRefs?: Set<string>;
}) => Promise<BuiltTransaction>;
export declare const buildSettingsUpdateTx: ({ desired, settingsHandleName, changeAddress: _changeAddress, spareUtxos: _spareUtxos, nativeScriptCborHex, blockfrostApiKey, userAgent, excludeUtxoRefs, orderScriptHashOverride, }: {
    desired: DesiredDeploymentState;
    settingsHandleName: string;
    changeAddress: string;
    spareUtxos: CardanoTypes.Utxo[];
    nativeScriptCborHex?: string;
    blockfrostApiKey?: string;
    userAgent?: string;
    excludeUtxoRefs?: Set<string>;
    orderScriptHashOverride?: string;
}) => Promise<BuiltTransaction>;
/**
 * Build an unsigned preparation tx that funds the admin address from the
 * script address. This is needed when the admin wallet has insufficient ADA
 * for the MPT root migration tx (which requires fees + collateral).
 *
 * Returns null if the admin address already has enough funds.
 */
export declare const buildPreparationTx: ({ desired, nativeScriptCborHex, blockfrostApiKey, userAgent, targetLovelace, excludeUtxoRefs, }: {
    desired: DesiredDeploymentState;
    nativeScriptCborHex?: string;
    blockfrostApiKey: string;
    userAgent: string;
    targetLovelace?: bigint;
    excludeUtxoRefs?: Set<string>;
}) => Promise<BuiltTransaction | null>;
export declare const assertMigrationPreservesRoot: (inlineDatumHex: string | undefined, newMptRootHash: string) => void;
/**
 * Build an unsigned tx that migrates the handle_root@handle_settings UTxO
 * from the old minting data script address to the new one, updating the
 * MPT root hash datum. Requires admin/policy key signature (not native script).
 *
 * The old validator CBOR should be the already-parameterized script as fetched
 * from the Handle API's /script endpoint for the current deployment subhandle.
 */
export declare const buildMptRootMigrationTx: ({ desired, newMptRootHash, oldValidatorCborHex, blockfrostApiKey, userAgent, }: {
    desired: DesiredDeploymentState;
    newMptRootHash: string;
    oldValidatorCborHex: string;
    blockfrostApiKey: string;
    userAgent: string;
}) => Promise<BuiltTransaction>;
