import { HandlePriceInfo, HandlePrices } from "../contracts/index.js";
declare const calculateHandlePriceFromHandlePriceInfo: (handle: string, handlePriceInfo: HandlePriceInfo) => bigint;
declare const calculateHandlePriceFromHandlePrices: (handle: string, handlePrices: HandlePrices) => number;
declare const calculateSubHandlePriceFromTierPricing: (subHandle: string, tierPricing: Array<Array<bigint>>) => bigint;
declare const parseHandle: (handle: string) => {
    isSubHandle: boolean;
    rootHandle: string;
    subHandle: string;
};
export { calculateHandlePriceFromHandlePriceInfo, calculateHandlePriceFromHandlePrices, calculateSubHandlePriceFromTierPricing, parseHandle, };
