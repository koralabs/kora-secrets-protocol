/**
 * Returns the smallest of the given bigint values.
 *
 * @param values - One or more bigint values
 * @returns The smallest of the given values
 * @throws {Error} If no values are provided
 */
export declare const minBigInt: (...values: bigint[]) => bigint;
/**
 * Returns the largest of the given bigint values.
 *
 * @param values - One or more bigint values
 * @returns The largest of the given values
 * @throws {Error} If no values are provided
 */
export declare const maxBigInt: (...values: bigint[]) => bigint;
