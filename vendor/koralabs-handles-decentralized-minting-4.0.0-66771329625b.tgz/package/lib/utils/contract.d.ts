import { ScriptDetails, ScriptType } from "@koralabs/kora-labs-common";
declare const fetchDeployedScript: (contractType: ScriptType) => Promise<ScriptDetails>;
declare const fetchDeployedScriptByHash: (contractType: ScriptType, expectedHash: string) => Promise<ScriptDetails>;
export { fetchDeployedScript, fetchDeployedScriptByHash };
