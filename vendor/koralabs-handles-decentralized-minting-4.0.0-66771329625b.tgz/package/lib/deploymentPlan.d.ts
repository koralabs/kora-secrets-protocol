import { Buffer } from "node:buffer";
import type { DesiredContractTarget, DesiredDeploymentState } from "./deploymentState.js";
import { buildReferenceScriptDeploymentTx, buildSettingsUpdateTx, type DeployerWallet } from "./deploymentTx.js";
/**
 * Compute the minting-data MPT root by fetching all handles AND their WS1 asset-label sets from the
 * api, then building the registry-aware trie — byte-identical to the engine's buildApiRootTrie and
 * the api's buildHandleSetTrie, and to what the on-chain demimntmpt validator maintains. The value
 * at each key is the handle's sorted CIP-67 label set ({001-004}); a handle holding none keeps "".
 * (Verified: this reproduces the live preview chain datum 9bb0ecbb over the 4054-handle set; the
 * label-blind value:"" root 94bdd2b8 does NOT match the chain and deadlocks every mint.) No ghost
 * handles. No fallback: if labels are unreachable we ABORT rather than migrate to a wrong root.
 */
export declare const computeMptRootHash: ({ network, userAgent, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    userAgent: string;
    fetchFn?: typeof fetch;
}) => Promise<string>;
/**
 * Fetch the old (currently deployed) validator script CBOR from the Handle
 * API's /script endpoint for the given deployment subhandle.
 */
export declare const fetchOldValidatorCbor: ({ network, currentSubhandle, userAgent, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    currentSubhandle: string;
    userAgent: string;
    fetchFn?: typeof fetch;
}) => Promise<string>;
export interface ExpectedContractState {
    contractSlug: string;
    scriptType: string;
    expectedScriptHash: string;
}
export interface LiveContractState {
    contractSlug: string;
    scriptType: string;
    currentScriptHash: string;
    currentSubhandle: string | null;
}
export interface UnsignedDeploymentTxArtifact {
    cborBytes: Buffer;
    cborHex: string;
    estimatedSignedTxSize: number;
    maxTxSize: number;
    consumedInputs: Set<string>;
}
export declare const renderTransactionOrderMarkdown: (transactionOrder: string[]) => string[];
export declare const discoverNextContractSubhandles: ({ network, contracts, liveContracts, userAgent, blockfrostApiKey, }: {
    network: "preview" | "preprod" | "mainnet";
    contracts: DesiredContractTarget[];
    liveContracts?: LiveContractState[];
    userAgent: string;
    blockfrostApiKey?: string | null;
}) => Promise<Record<string, string>>;
interface LiveSettingsState {
    currentSettingsUtxoRefs: Record<string, string>;
    values: DesiredDeploymentState["settings"]["values"] | null;
}
export declare const assertPzScriptAddressIsCurrentProxy: ({ network, pzScriptAddress, userAgent, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    pzScriptAddress: string;
    userAgent: string;
    fetchFn?: typeof fetch;
}) => Promise<void>;
export declare const handlesApiBaseUrlForNetwork: (network: string) => string;
export declare const buildExpectedContractStates: (desired: DesiredDeploymentState, buildContractsFn?: (params: import("./contracts/config.js").BuildContractsParams) => import("./contracts/config.js").BuiltContracts) => ExpectedContractState[];
export declare const fetchLiveContractStates: ({ network, contracts, userAgent, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    contracts: DesiredContractTarget[];
    userAgent: string;
    fetchFn?: typeof fetch;
}) => Promise<LiveContractState[]>;
export declare const fetchLiveSettingsState: ({ network, userAgent, fetchFn, }: {
    network: "preview" | "preprod" | "mainnet";
    userAgent: string;
    fetchFn?: typeof fetch;
}) => Promise<LiveSettingsState>;
export declare const buildDeploymentPlan: ({ desired, expectedContracts, liveContracts, liveSettings, nextSubhandles, }: {
    desired: DesiredDeploymentState;
    expectedContracts: ExpectedContractState[];
    liveContracts: LiveContractState[];
    liveSettings: LiveSettingsState;
    nextSubhandles?: Record<string, string>;
}) => {
    planId: string;
    summaryJson: {
        plan_id: string;
        repo: string;
        network: "mainnet" | "preprod" | "preview";
        contracts: {
            contract_slug: string;
            script_type: string;
            drift_type: string;
            script_hashes: {
                current: string;
                expected: string;
            };
            settings: {
                type: "decentralized_minting_settings";
                diff_rows: {
                    path: string;
                    current: unknown;
                    desired: unknown;
                }[];
                desired_values: unknown;
                ignored_paths: string[];
            };
            subhandle: {
                action: string;
                value: string | null;
            };
            expected_post_deploy_state: {
                repo: string;
                network: "mainnet" | "preprod" | "preview";
                contract_slug: string;
                expected_script_hash: string;
                expected_subhandle: string | null;
                assigned_handles: {
                    settings: string[];
                    scripts: string[];
                };
                settings: {
                    type: "decentralized_minting_settings";
                    values: unknown;
                    ignored_paths: string[];
                };
            };
        }[];
        transaction_order: never[];
    };
    summaryMarkdown: string;
    deploymentPlanJson: {
        plan_id: string;
        repo: string;
        network: "mainnet" | "preprod" | "preview";
        contracts: {
            repo: string;
            network: "mainnet" | "preprod" | "preview";
            contract_slug: string;
            expected_script_hash: string;
            expected_subhandle: string | null;
            assigned_handles: {
                settings: string[];
                scripts: string[];
            };
            settings: {
                type: "decentralized_minting_settings";
                values: unknown;
                ignored_paths: string[];
            };
        }[];
        transaction_order: never[];
    };
};
export declare const buildUnsignedDeploymentTxArtifact: ({ desired, contract, handleName, deployer, nativeScriptCborHex, blockfrostApiKey, userAgent, excludeUtxoRefs, buildTxFn, maxTxSize: maxTxSizeOverride, }: {
    desired: DesiredDeploymentState;
    contract: DesiredContractTarget;
    handleName: string;
    deployer: DeployerWallet;
    nativeScriptCborHex?: string;
    blockfrostApiKey?: string;
    userAgent?: string;
    excludeUtxoRefs?: Set<string>;
    buildTxFn?: typeof buildReferenceScriptDeploymentTx;
    maxTxSize?: number;
}) => Promise<UnsignedDeploymentTxArtifact>;
export declare const buildUnsignedSettingsUpdateTxArtifact: ({ desired, settingsHandleName, deployer, nativeScriptCborHex, blockfrostApiKey, userAgent, excludeUtxoRefs, orderScriptHashOverride, buildTxFn, maxTxSize: maxTxSizeOverride, }: {
    desired: DesiredDeploymentState;
    settingsHandleName: string;
    deployer: DeployerWallet;
    nativeScriptCborHex?: string;
    blockfrostApiKey?: string;
    userAgent?: string;
    excludeUtxoRefs?: Set<string>;
    orderScriptHashOverride?: string;
    buildTxFn?: typeof buildSettingsUpdateTx;
    maxTxSize?: number;
}) => Promise<UnsignedDeploymentTxArtifact>;
export {};
