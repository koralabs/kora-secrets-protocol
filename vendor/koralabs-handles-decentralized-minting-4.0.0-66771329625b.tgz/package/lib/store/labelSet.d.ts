/** Does the canonical label set contain `label`? */
export declare const contains: (set: string, label: string) => boolean;
/** Insert `label`, keeping the set sorted ascending. Throws if already present. */
export declare const insert: (set: string, label: string) => string;
/** Remove `label`. Throws if absent. */
export declare const remove: (set: string, label: string) => string;
/** Apply a +1 (add) / -1 (remove) delta — couples the value change to the tx mint/burn. */
export declare const apply: (set: string, label: string, amount: bigint) => string;
/** The raw value bytes to store in the Trie (UTF-8-safe). */
export declare const valueBuffer: (set: string) => Buffer;
