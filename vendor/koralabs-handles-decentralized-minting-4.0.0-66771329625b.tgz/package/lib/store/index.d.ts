import { Trie } from "@aiken-lang/merkle-patricia-forestry";
/**
 * DESIGN LAW — the handle MPT is API-only sourced, NEVER disk-cached.
 *
 * The Merkle Patricia Trie of minted handles is ALWAYS rebuilt fresh,
 * in-memory, from the handle registry API on every invocation, and verified
 * against the on-chain root before use. The engine hard-errors on
 * "Local DB and On Chain Root Hash mismatch" (see src/txs/prepareNewMint.ts)
 * precisely so a wrong local trie can never be minted against. The trie is
 * NEVER persisted to, nor loaded from, local disk.
 *
 * Why no disk cache:
 *  - The on-chain root (read via the API) is the ONLY source of truth. Any
 *    local on-disk copy is a second copy that can silently drift from it.
 *  - The minting engine runs in a Lambda. Local disk (/tmp) is ephemeral and
 *    survives unpredictably across warm invocations — so a disk cache is both
 *    useless (cold starts see nothing) AND a correctness hazard (a warm
 *    container can load a stale root). A cache that "sometimes persists" is
 *    worse than no cache at all.
 *  - Rebuilding from the API is cheap relative to the cost of minting against
 *    stale state. If the API is unreachable, ABORT the mint — there is no
 *    fallback to a local copy.
 *
 * Canonical production build: minting.handle.me `verifyRootHash` /
 * `buildApiRootTrie` — fetch all handles via the `/handles` endpoint and
 * `Trie.fromList(...)`, then verify the computed root equals the on-chain
 * `mpt_root_hash`. `buildTrie` below mirrors that in-memory construction for
 * SDK/CLI consumers.
 *
 * Do NOT reintroduce a disk-backed `Store(folder)` (or `fs`) here. The
 * disk-`Store` path was removed 2026-06-07 after an automated self-fix
 * (PR #43) tried to "repair" a disk-load branch that production never called
 * — fixing dead code and entrenching the very cache pattern this law forbids.
 * The `tests/store.unit.test.ts` guard fails CI if disk coupling returns.
 */
/** An API-sourced handle and its explicit canonical registry label set. */
export interface HandleRegistryEntry {
    name: string;
    labels: string;
}
/**
 * Build the handle MPT in-memory from the handle list + per-handle label sets (API-sourced).
 * Mirrors the production `buildApiRootTrie`. No disk Store.
 *
 * LABEL-AWARE — labels are REQUIRED per handle (no bare-string overload, on purpose). The registry
 * value at each key is the handle's sorted, unique four-byte label set; "" only when it holds
 * none. A names-only `value:""` trie silently computes the WRONG (label-blind) root and deadlocks
 * every engine-verify mint (the on-chain `demimntmpt` root is label-aware), so the type forbids it.
 * For a handle that genuinely has no labels, pass `{ name, labels: "" }`.
 */
declare const buildTrie: (handles: readonly HandleRegistryEntry[]) => Promise<Trie>;
declare const inspect: (db: Trie) => Promise<void>;
/**
 * Incremental in-memory insert helper (CLI / debug). The canonical full-set
 * build is `buildTrie` / `Trie.fromList`; prefer it for constructing the
 * whole handle trie. Operates on whatever in-memory `Trie` is passed.
 */
declare const fillHandles: (db: Trie, handles: readonly HandleRegistryEntry[], progress: () => void) => Promise<void>;
declare const addHandle: (db: Trie, key: string, value: string) => Promise<void>;
declare const removeHandle: (db: Trie, key: string) => Promise<void>;
declare const printProof: (db: Trie, key: string, format: "json" | "cborHex") => Promise<void>;
export { addHandle, buildTrie, fillHandles, inspect, printProof, removeHandle };
