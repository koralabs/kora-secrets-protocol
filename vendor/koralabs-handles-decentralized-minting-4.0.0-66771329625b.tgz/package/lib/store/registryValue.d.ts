/**
 * Byte-identical to on-chain `registry_value.encode(labels)` — the value is exactly the label set.
 */
export declare const encode: (labels: string) => string;
