import { Result } from "ts-res";
import { HandlePriceInfo, MintingData, Settings, SettingsV1 } from "../contracts/index.js";
import { type NetworkName } from "../helpers/cardano-sdk/networkName.js";
/**
 * Output UTxO descriptor returned by the settings/minting-data/handle-price
 * lookups. Replaces the Helios `TxInput` with the minimum data a tx builder
 * needs to spend from — or reference — this UTxO.
 */
export interface UtxoDescriptor {
    txHash: string;
    outputIndex: number;
    address: string;
    lovelace: bigint;
    /** Non-lovelace assets, keyed by `${policyIdHex}.${assetNameHex}`. */
    assets: Map<string, bigint>;
    /** Inline datum CBOR hex, if present. */
    inlineDatumCbor?: string;
}
declare const fetchSettings: (network: NetworkName) => Promise<Result<{
    settings: Settings;
    settingsV1: SettingsV1;
    settingsUtxo: UtxoDescriptor;
}, string>>;
declare const fetchMintingData: () => Promise<Result<{
    mintingData: MintingData;
    mintingDataUtxo: UtxoDescriptor;
}, string>>;
/**
 * Fetch Handle Price Info Data
 * @param handlePriceAssetName - The name of the handle price asset in UTF8
 */
declare const fetchHandlePriceInfoData: (handlePriceAssetName: string) => Promise<Result<{
    handlePriceInfo: HandlePriceInfo;
    handlePriceInfoUtxo: UtxoDescriptor;
}, string>>;
export declare const decodeInlineDatum: (cbor: string) => import("../contracts/index.js").PlutusData;
export { fetchHandlePriceInfoData, fetchMintingData, fetchSettings };
