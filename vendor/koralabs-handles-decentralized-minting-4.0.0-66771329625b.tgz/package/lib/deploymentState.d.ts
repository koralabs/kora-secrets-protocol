export interface DesiredContractTarget {
    contractSlug: string;
    scriptType: string;
    oldScriptType: string | null;
    deploymentHandleSlug: string;
    build: {
        contractName: string;
        kind: string;
    };
}
export interface DesiredDeploymentState {
    schemaVersion: 2;
    network: "preview" | "preprod" | "mainnet";
    buildParameters: {
        mintVersion: number;
        legacyPolicyId: string;
        adminVerificationKeyHash: string;
    };
    assignedHandles: {
        settings: string[];
        scripts: string[];
    };
    ignoredSettings: string[];
    settings: {
        type: "decentralized_minting_settings";
        values: {
            "demi@handle_settings": {
                mint_governor: string;
                mint_version: number;
                policy_id: string;
                allowed_minters: string[];
                valid_handle_price_assets: string[];
                treasury_address: string;
                treasury_fee_percentage: number;
                pz_script_address: string;
                order_script_hash: string;
                minting_data_script_hash: string;
                sub_handle_minter_fee: number;
                sub_handle_treasury_fee: number;
            };
            "handle_root@handle_settings": {
                mpt_root_hash: string;
            };
            "kora@handle_prices": {
                current_data: number[];
                prev_data: number[];
            };
        };
    };
    contracts: DesiredContractTarget[];
}
export declare const loadDesiredDeploymentState: (path: string) => Promise<DesiredDeploymentState>;
export declare const parseDesiredDeploymentState: (raw: string, sourceLabel?: string) => DesiredDeploymentState;
