import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { Result } from "ts-res";
import { fetchHandlePriceInfoData, fetchMintingData, fetchSettings } from "../configs/index.js";
import { HandlePriceInfo, HandlePrices, NewHandle, Settings, SettingsV1 } from "../contracts/index.js";
import { DeployedScripts, fetchAllDeployedScripts } from "./deploy.js";
import type { TxPlan } from "./txPlan.js";
interface PrepareNewMintParams {
    changeAddress: string;
    /** Payment-key-hash of the minter (required signer). */
    minterKeyHash: string;
    latestHandlePrices: HandlePrices;
    handles: NewHandle[];
    walletUtxos: CardanoTypes.Utxo[];
    collateralUtxo?: CardanoTypes.Utxo;
    db: Trie;
    blockfrostApiKey: string;
    /**
     * WS5 — extra reference inputs required to satisfy discounted orders: each qualifying asset
     * (rare/OG handle, partner/HAL NFT) plus the $pfp_policy_ids allowlist-root UTxO. Resolved by
     * the caller (it has the orders + chain access via `resolveDiscountReferenceInputs`). The mint
     * validator reads these to re-verify every discount claim.
     */
    discountReferenceInputs?: {
        txHash: string;
        outputIndex: number;
    }[];
}
interface PrepareNewMintDeps {
    fetchAllDeployedScriptsFn?: typeof fetchAllDeployedScripts;
    fetchMintingDataFn?: typeof fetchMintingData;
    fetchSettingsFn?: typeof fetchSettings;
    fetchHandlePriceInfoDataFn?: typeof fetchHandlePriceInfoData;
}
declare const prepareNewMintTransaction: (params: PrepareNewMintParams, { fetchAllDeployedScriptsFn, fetchMintingDataFn, fetchSettingsFn, fetchHandlePriceInfoDataFn, }?: PrepareNewMintDeps) => Promise<Result<{
    plan: TxPlan;
    deployedScripts: DeployedScripts;
    settings: Settings;
    settingsV1: SettingsV1;
    handlePriceInfo: HandlePriceInfo;
}, Error>>;
export type { PrepareNewMintParams };
export { prepareNewMintTransaction };
