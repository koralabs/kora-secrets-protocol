import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { Result } from "ts-res";
import { fetchMintingData } from "../configs/index.js";
import { LegacyHandle } from "../contracts/index.js";
import { DeployedScripts, fetchAllDeployedScripts } from "./deploy.js";
import type { TxPlan } from "./txPlan.js";
interface PrepareLegacyBurnParams {
    /** Change address (bech32) of the minter wallet. */
    changeAddress: string;
    /** Payment-key-hash of the minter (required signer). */
    minterKeyHash: string;
    /** Wallet UTxOs available for fees. */
    walletUtxos: CardanoTypes.Utxo[];
    /** Collateral UTxO (ADA-only, ≥5 ADA). */
    collateralUtxo?: CardanoTypes.Utxo;
    /** Handles to burn (e.g. virtual sub handles); deleted from the MPT. */
    handles: LegacyHandle[];
    db: Trie;
    blockfrostApiKey: string;
}
interface PrepareLegacyBurnDeps {
    fetchAllDeployedScriptsFn?: typeof fetchAllDeployedScripts;
    fetchMintingDataFn?: typeof fetchMintingData;
}
/**
 * WS2 — prepare the minting-data spend component of a legacy *burn* transaction.
 *
 * The mirror of `prepareLegacyMintTransaction`: for each handle we generate an MPT *inclusion*
 * proof (against the current root, which still contains the key) and then delete the key from
 * the local trie, advancing the root. The `BurnLegacyHandles` redeemer carries those proofs;
 * on-chain `process_legacy_handles(amount = -1)` applies `mpt.delete` and requires the tx to
 * burn exactly the corresponding assets. This keeps the MPT root in sync when a legacy
 * (virtual) sub-handle is burned, instead of the DB-only delete that silently drifts the root.
 *
 * The caller adds the actual asset burns (negative mint under the legacy native policy) before
 * `finalizeTxPlan`.
 */
declare const prepareLegacyBurnTransaction: (params: PrepareLegacyBurnParams, { fetchAllDeployedScriptsFn, fetchMintingDataFn, }?: PrepareLegacyBurnDeps) => Promise<Result<{
    plan: TxPlan;
    deployedScripts: DeployedScripts;
}, Error>>;
export type { PrepareLegacyBurnParams };
export { prepareLegacyBurnTransaction };
