import { ScriptDetails } from "@koralabs/kora-labs-common";
import { Result } from "ts-res";
import type { NetworkName } from "../helpers/cardano-sdk/networkName.js";
/**
 * Inputs to `deploy`. `NetworkName` is now a local literal union — no Helios.
 */
interface DeployParams {
    network: NetworkName;
    /** Mint Version — parameter in the demimntprx.mint validator. */
    mintVersion: bigint;
    /** Legacy handle policy id. */
    legacyPolicyId: string;
    /** Admin verification key hash — parameter in demimntmpt.spend. */
    adminVerificationKeyHash: string;
    /** Which contract blueprint to extract. */
    contractName: string;
}
interface DeployData {
    /** Double-CBOR of the parameterized optimized script. */
    optimizedCbor: string;
    /** Double-CBOR of the parameterized unoptimized script. */
    unOptimizedCbor?: string;
    /**
     * Plutus language version of this validator. The three non-proxy DeMi
     * validators are V3 (aiken v1.1.22); the frozen mint proxy is V2. The
     * deployment tx wraps the reference script with the matching
     * `PlutusVxScript`, so this must be threaded through.
     */
    plutusVersion: "v2" | "v3";
    /** Inline datum CBOR (settings-proxy parameter echo) — when applicable. */
    datumCbor?: string;
    /** Script hash (28-byte hex). */
    validatorHash: string;
    /** Policy id — only set for the mint-proxy. */
    policyId?: string;
    /** Script bech32 address — only set for spending validators. */
    scriptAddress?: string;
    /** Script reward-account — only set for the withdraw validator. */
    scriptStakingAddress?: string;
}
/**
 * Produce the CBORs + datum + hashes for one of the De-Mi validators. The
 * on-chain deployment plan generator consumes this.
 */
declare const deploy: (params: DeployParams) => Promise<DeployData>;
/**
 * Reference-script UTxO descriptor for a deployed validator. Replaces the
 * Helios `TxInput` with the minimum the tx builders actually need.
 */
export interface DeployedScriptRef {
    details: ScriptDetails;
    refScriptUtxo: {
        txHash: string;
        outputIndex: number;
    };
    /** Double-CBOR of the on-chain script (used to recompute hashes). */
    optimizedCbor: string;
    /** Double-CBOR of the off-chain unoptimized fallback if present. */
    unoptimizedCbor?: string;
}
interface DeployedScripts {
    mintProxyScript: DeployedScriptRef;
    mintingDataScript: DeployedScriptRef;
    mintV1Script: DeployedScriptRef;
    ordersScript: DeployedScriptRef;
}
declare const fetchAllDeployedScripts: (expected?: {
    mintingDataScriptHash?: string;
    mintGovernorHash?: string;
}) => Promise<Result<DeployedScripts, string>>;
export type { DeployData, DeployedScripts, DeployParams };
export { deploy, fetchAllDeployedScripts };
