import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { Result } from "ts-res";
import { fetchMintingData } from "../configs/index.js";
import { LegacyHandle } from "../contracts/index.js";
import { DeployedScripts, fetchAllDeployedScripts } from "./deploy.js";
import type { TxPlan } from "./txPlan.js";
interface PrepareLegacyMintParams {
    /** Change address (bech32) of the minter wallet. */
    changeAddress: string;
    /** Payment-key-hash of the minter (required signer). */
    minterKeyHash: string;
    /** Wallet UTxOs available for fees. */
    walletUtxos: CardanoTypes.Utxo[];
    /** Collateral UTxO (ADA-only, ≥5 ADA). */
    collateralUtxo?: CardanoTypes.Utxo;
    handles: LegacyHandle[];
    db: Trie;
    blockfrostApiKey: string;
    /**
     * For subhandle mints: each root's 001 OwnerSettings reference input (the validator's
     * `find_root_handle_settings` reads the owner's tier pricing + payment_address) plus the
     * additive fee outputs the contract now enforces — owner royalty → owner's payment_address,
     * flat minter fee → an allowed minter, flat treasury fee → treasury_address. The caller
     * computes these from the batch's subhandles (each skipped when its amount is 0); the package
     * stays fee-agnostic and simply appends them. Root mints need neither. The settings reference
     * input (for `find_settings`) is attached automatically for every legacy mint.
     */
    subHandleReferenceInputs?: {
        txHash: string;
        outputIndex: number;
    }[];
    feeOutputs?: CardanoTypes.TxOut[];
}
interface PrepareLegacyMintDeps {
    fetchAllDeployedScriptsFn?: typeof fetchAllDeployedScripts;
    fetchMintingDataFn?: typeof fetchMintingData;
}
/**
 * Prepare the minting-data spend component of a legacy mint transaction.
 * Returns a partial `TxPlan` that captures the minting-data UTxO spend with
 * the MintLegacyHandles redeemer + the updated MPT root datum output. The
 * caller (`mintLegacyHandles`) adds the actual minted-handle outputs and
 * mints before calling `finalizeTxPlan`.
 */
declare const prepareLegacyMintTransaction: (params: PrepareLegacyMintParams, { fetchAllDeployedScriptsFn, fetchMintingDataFn, }?: PrepareLegacyMintDeps) => Promise<Result<{
    plan: TxPlan;
    deployedScripts: DeployedScripts;
}, Error>>;
declare const reconstructUtxo: (descriptor: import("../configs/index.js").UtxoDescriptor) => CardanoTypes.Utxo;
export type { PrepareLegacyMintParams };
export { prepareLegacyMintTransaction, reconstructUtxo };
