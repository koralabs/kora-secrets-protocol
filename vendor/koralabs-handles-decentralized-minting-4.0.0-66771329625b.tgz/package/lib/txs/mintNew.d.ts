import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { Result } from "ts-res";
import { HandlePriceInfo, HandlePrices, type SettingsV1 } from "../contracts/index.js";
import { type DeployedScripts } from "./deploy.js";
import { type FinalizedTx, type TxPlan } from "./txPlan.js";
/**
 * The fully-augmented orders-path mint plan (minting-data MintDeMiHandles spend + per-order token
 * mints + ref/user outputs + order spends), BEFORE coin selection / finalization. Engines that need
 * to inject additional outputs (the additive owner/minter/treasury fee outputs — DSH-501) or
 * finalize with auxiliary data (free-virtual tx metadata) consume this and run their own finalize;
 * `mintNewHandles` is the thin wrapper that just `finalizeTxPlan`s it.
 */
export interface MintDeMiHandlesPlan {
    plan: TxPlan;
    deployedScripts: DeployedScripts;
    settingsV1: SettingsV1;
    handlePriceInfo: HandlePriceInfo;
}
interface MintDeMiHandlesParams {
    changeAddress: string;
    minterKeyHash: string;
    latestHandlePrices: HandlePrices;
    ordersTxInputs: CardanoTypes.Utxo[];
    walletUtxos: CardanoTypes.Utxo[];
    collateralUtxo?: CardanoTypes.Utxo;
    db: Trie;
    blockfrostApiKey: string;
}
/**
 * Mint new handles by consuming `ordersTxInputs` (UTxOs at the orders-spend
 * script), extending the prepare-new-mint spec with the per-order mint ops
 * (policy-tokens mint + ref/user handle outputs), and finalizing to unsigned
 * CBOR.
 */
declare const buildMintDeMiHandlesPlan: (params: MintDeMiHandlesParams) => Promise<Result<MintDeMiHandlesPlan, Error>>;
/**
 * Mint new handles by consuming `ordersTxInputs` and finalizing to unsigned CBOR. Thin wrapper over
 * `buildMintDeMiHandlesPlan` — callers that need to inject fee outputs / tx metadata should use
 * `buildMintDeMiHandlesPlan` directly and run their own finalize.
 */
declare const mintNewHandles: (params: MintDeMiHandlesParams) => Promise<Result<FinalizedTx, Error>>;
export type { MintDeMiHandlesParams };
export { buildMintDeMiHandlesPlan, mintNewHandles };
