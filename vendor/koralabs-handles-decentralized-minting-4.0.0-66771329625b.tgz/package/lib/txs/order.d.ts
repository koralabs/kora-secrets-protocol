import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { ScriptDetails } from "@koralabs/kora-labs-common";
import { Result } from "ts-res";
import { DiscountClaim, HandlePrices } from "../contracts/index.js";
import { type NetworkName } from "../helpers/cardano-sdk/index.js";
interface RequestParams {
    network: NetworkName;
    /** Bech32 payment address — must have both payment + staking credentials. */
    address: string;
    /** Handle name (UTF8). */
    handle: string;
    /**
     * WS5 — optional minting-discount. `bps` is the configured basis-points percent-off for the
     * claimed class (read from on-chain SettingsV1.discount_config); `claim` names the qualifying
     * asset, which the fulfilment tx must reference (sharing a credential with `address`). The
     * order pays the discounted price; the validator re-verifies the claim + bps on-chain.
     */
    discount?: {
        claim: DiscountClaim;
        bps: number;
    };
}
/**
 * Build the inline datum + lovelace value for a new order output. The caller
 * places this output at the orders-script address and does its own coin
 * selection. Returns the data needed to construct that output, not a tx.
 *
 * Returning the primitives rather than a half-built tx matches the
 * cardano-sdk style of composition — consumers feed these into their
 * normal build pipeline.
 */
declare const request: (params: RequestParams) => Promise<Result<{
    scriptAddress: string;
    lovelace: bigint;
    orderDatumCbor: string;
}, Error>>;
interface CancelParams {
    network: NetworkName;
    address: string;
    orderUtxo: CardanoTypes.Utxo;
    walletUtxos: CardanoTypes.Utxo[];
    collateralUtxo?: CardanoTypes.Utxo;
    blockfrostApiKey: string;
    /** Reference-input for the orders script (same script is the spend target). */
    ordersScriptRef?: {
        txHash: string;
        outputIndex: number;
    };
}
/**
 * Cancel an order UTxO — spend it back to the owner's address via the orders
 * Plutus script. Returns the primitives needed to build this as a Plutus-spend
 * tx.
 */
declare const cancel: (params: CancelParams) => Promise<Result<{
    cancelRedeemerCbor: string;
    requiredSignerHash: string;
}, Error>>;
interface FetchOrdersTxInputsParams {
    network: NetworkName;
    ordersScriptDetail: ScriptDetails;
    blockfrostApiKey: string;
}
/**
 * Read the current UTxO set at the orders script address, filtered to those
 * with a well-formed order datum.
 */
declare const fetchOrdersTxInputs: (params: FetchOrdersTxInputsParams) => Promise<Result<CardanoTypes.Utxo[], Error>>;
interface IsValidOrderTxInputParams {
    network: NetworkName;
    orderUtxo: CardanoTypes.Utxo;
    prevHandlePrices: HandlePrices;
    currentHandlePrices: HandlePrices;
}
declare const isValidOrderTxInput: (params: IsValidOrderTxInputParams) => Promise<Result<true, Error>>;
export type { CancelParams, FetchOrdersTxInputsParams, RequestParams };
export { cancel, fetchOrdersTxInputs, isValidOrderTxInput, request };
