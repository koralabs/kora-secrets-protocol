import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { Result } from "ts-res";
import { fetchMintingData, fetchSettings } from "../configs/index.js";
import { MintingData, NewHandle, type SettingsV1 } from "../contracts/index.js";
import { DeployedScripts, fetchAllDeployedScripts } from "./deploy.js";
import type { TxPlan } from "./txPlan.js";
interface PrepareNewMintDataParams {
    changeAddress: string;
    /** Payment-key-hash of the minter (required signer). */
    minterKeyHash: string;
    /** Index into `settings.allowed_minters` for the MintDeMiHandles redeemer. */
    minterIndex?: bigint;
    handles: NewHandle[];
    collateralUtxo?: CardanoTypes.Utxo;
    db: Trie;
    blockfrostApiKey: string;
}
interface PrepareNewMintDataDeps {
    fetchAllDeployedScriptsFn?: typeof fetchAllDeployedScripts;
    fetchMintingDataFn?: typeof fetchMintingData;
    fetchSettingsFn?: typeof fetchSettings;
}
/**
 * The minimal orders-path `MintDeMiHandles` minting-data spend, for callers (the engine) that build
 * their OWN token outputs (with rich CIP-68 datums), additive fee outputs, mint map (under the DeMi
 * mint-proxy policy), order spends, and finalize with auxiliary data. This is the orders-path analog
 * of `prepareLegacyMintTransaction`'s minimal plan, but with the `MintDeMiHandles(OrderProof[])`
 * redeemer + the MPT-root update from `buildOrderProofs` (sub-key inserts + free-virtual root bumps).
 *
 * Returns ONLY: the minting-data input preselected + its updated datum output, the MintDeMiHandles
 * spend redeemer, the settings + minting-data reference inputs, the minter required-signer, and the
 * deployed scripts (so the caller can wire the mint-proxy / orders / mint_v1 refs + redeemers). It
 * intentionally does NOT add handle-price-info / treasury / minter / token outputs — those are
 * root-mint or engine concerns.
 */
export declare const prepareNewMintDataSpend: (params: PrepareNewMintDataParams, { fetchAllDeployedScriptsFn, fetchMintingDataFn, fetchSettingsFn, }?: PrepareNewMintDataDeps) => Promise<Result<{
    plan: TxPlan;
    deployedScripts: DeployedScripts;
    settingsV1: SettingsV1;
    newMintingData: MintingData;
}, Error>>;
export {};
