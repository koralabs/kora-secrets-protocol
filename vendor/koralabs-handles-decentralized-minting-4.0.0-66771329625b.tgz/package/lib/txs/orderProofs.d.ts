import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import { type NewHandle, type OrderProof } from "../contracts/index.js";
/**
 * DSH-403 — build the per-order `OrderProof`s for a DeMi `MintDeMiHandles` tx, advancing the local
 * trie exactly as the contract's `all_orders_are_satisfied` does so the on-chain `mpt` ops verify:
 *
 *  1. Insert the handle's OWN key with an empty value (`mpt.insert(root, handle, #"", proof)`), in
 *     order-input order. This is identical for root / nft sub / virtual sub — every mint inserts.
 *
 * Mutates `db`; callers read `db.hash` afterwards for the new minting-data root.
 */
export declare const buildOrderProofs: (db: Trie, handles: NewHandle[]) => Promise<OrderProof[]>;
