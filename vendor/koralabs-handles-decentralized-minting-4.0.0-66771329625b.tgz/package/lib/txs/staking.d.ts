import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { getBlockfrostBuildContext } from "../helpers/cardano-sdk/blockfrostContext.js";
import { type NetworkName } from "../helpers/cardano-sdk/index.js";
/**
 * Register a staking credential. Returns unsigned tx CBOR.
 */
declare const registerStakingAddress: ({ network, changeAddress, spareUtxos, bech32StakingAddress, blockfrostApiKey, getBuildContext, }: {
    network: NetworkName;
    changeAddress: string;
    spareUtxos: CardanoTypes.Utxo[];
    bech32StakingAddress: string;
    blockfrostApiKey: string;
    getBuildContext?: typeof getBlockfrostBuildContext;
}) => Promise<string>;
export { registerStakingAddress };
