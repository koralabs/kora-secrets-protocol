import { Trie } from "@aiken-lang/merkle-patricia-forestry";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import { Result } from "ts-res";
import { fetchMintingData, fetchSettings } from "../configs/index.js";
import { DeployedScripts, fetchAllDeployedScripts } from "./deploy.js";
import type { TxPlan } from "./txPlan.js";
/** One label asset (e.g. 001 settings) to mint (+1) or burn (-1) for a root handle. */
interface LabelAssetRequest {
    /** Root handle name (UTF-8) — the MPT key. */
    utf8Name: string;
    /** Root handle name (hex) — the MPT key encoded for the proof. */
    hexName: string;
    /** 4-byte CIP-67 label prefix (hex), e.g. "00001070" for 001. */
    label: string;
    /** +1 to add the label (mint the asset) / -1 to remove it (burn). */
    amount: bigint;
    /** The key's current label set (hex; "" if none yet). */
    oldLabels: string;
    /** The root's 222 owner-NFT UTxO to reference (proves ownership + fixes the policy). */
    ownerRefInput: {
        txHash: string;
        outputIndex: number;
    };
}
interface PrepareLabelAssetsParams {
    changeAddress: string;
    /** Minter key hash — must be the `allowed_minter` at `minterIndex` in settings. */
    minterKeyHash: string;
    minterIndex: bigint;
    walletUtxos: CardanoTypes.Utxo[];
    collateralUtxo?: CardanoTypes.Utxo;
    requests: LabelAssetRequest[];
    db: Trie;
    blockfrostApiKey: string;
}
interface PrepareLabelAssetsDeps {
    fetchAllDeployedScriptsFn?: typeof fetchAllDeployedScripts;
    fetchMintingDataFn?: typeof fetchMintingData;
    fetchSettingsFn?: typeof fetchSettings;
}
/**
 * WS1 — prepare the minting-data spend of a label-asset mint/burn transaction.
 *
 * DeMi becomes the minter of the per-handle label assets (001 settings, future 002, …). For
 * each request we update the handle key's MPT value (its canonical label set) via a single
 * `mpt.update` proof — add the label (+1) or remove it (−1) — and the `MintLabelAssets`
 * redeemer requires the tx to mint exactly the matching ±1 of `(policy, label ‖ handle_name)`.
 * Authorization is the `allowed_minter` signature plus the root's 222 owner NFT referenced as
 * an input (which also fixes the label asset's policy on-chain). The caller adds the actual
 * label-asset mint/burn entries + their outputs/datums before `finalizeTxPlan`.
 */
declare const prepareLabelAssetsTransaction: (params: PrepareLabelAssetsParams, { fetchAllDeployedScriptsFn, fetchMintingDataFn, fetchSettingsFn, }?: PrepareLabelAssetsDeps) => Promise<Result<{
    plan: TxPlan;
    deployedScripts: DeployedScripts;
}, Error>>;
export type { LabelAssetRequest, PrepareLabelAssetsParams };
export { prepareLabelAssetsTransaction };
