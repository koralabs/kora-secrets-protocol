import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import type { Ed25519KeyHashHex } from "@cardano-sdk/crypto";
import type { BlockfrostBuildContext } from "../helpers/cardano-sdk/blockfrostContext.js";
/**
 * Shared Plutus-tx spec used by the DeMi tx builders. A `TxPlan` captures
 * all the declarative intent of a tx — inputs, outputs, redeemers, mints,
 * withdrawals, reference inputs — and `finalizeTxPlan` runs coin selection,
 * Conway-correct script_data_hash computation, and CBOR serialization.
 *
 * Callers never touch `@helios-lang/*`. They never touch cardano-sdk's
 * broken Alonzo-array-format script_data_hash either — this helper uses
 * the ported MAP-format `computeScriptDataHash` under the hood.
 */
export interface TxPlan {
    /** Preselected UTxOs (contract spends + token-carrying wallet UTxOs). */
    preSelectedUtxos: CardanoTypes.Utxo[];
    /** Additional wallet UTxOs to cover fees. */
    spareUtxos: CardanoTypes.Utxo[];
    /** Required outputs. Coin values are pre-filled; the selector may add change. */
    outputs: CardanoTypes.TxOut[];
    /** Reference inputs (script refs + reference datums). */
    referenceInputs?: Set<CardanoTypes.TxIn>;
    /** Tokens minted/burned keyed by asset id. */
    mint?: Map<CardanoTypes.AssetId, bigint>;
    /** Withdrawals keyed by reward account (bech32). */
    withdrawals?: Map<CardanoTypes.RewardAccount, bigint>;
    /** Certificates (stake registration, etc). */
    certificates?: CardanoTypes.Certificate[];
    /** All redeemers (spend/mint/cert/withdraw). */
    redeemers?: CardanoTypes.Redeemer[];
    /** Required ed25519 key-hash signers in addition to wallet signers. */
    requiredSigners?: Ed25519KeyHashHex[];
    /** Plutus language versions actually used in this tx. */
    usedPlutusVersions?: CardanoTypes.PlutusLanguageVersion[];
    /** Collateral UTxO(s) for Plutus-spending txs. */
    collateralUtxo?: CardanoTypes.Utxo;
    /** Change address (bech32). Defaults to the first wallet UTxO's address. */
    changeAddress: string;
    /** Blockfrost build context (protocol params + validity interval). */
    buildContext: BlockfrostBuildContext;
    /** Optional pre-computed datums attached in the witness set (non-inline). */
    datums?: CardanoTypes.PlutusData[];
}
export interface FinalizedTx {
    /** Unsigned tx CBOR hex. */
    cborHex: string;
    /** txHash (matches body hash). */
    txHash: string;
    /** UTxO refs consumed as inputs. */
    consumedInputs: Set<string>;
    /** Estimated signed tx size in bytes. */
    estimatedSignedTxSize: number;
}
export declare const finalizeTxPlan: (plan: TxPlan) => Promise<FinalizedTx>;
