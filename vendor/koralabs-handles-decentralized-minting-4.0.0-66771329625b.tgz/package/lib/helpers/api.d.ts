declare const fetchApi: (endpoint: string, params?: any) => Promise<Response>;
export { fetchApi };
