import type { NetworkName } from "../cardano-sdk/networkName.js";
declare const getNetwork: (apiKey: string) => NetworkName;
export { getNetwork };
