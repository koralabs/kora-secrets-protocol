import { Result } from "ts-res";
type Callback<T> = () => T;
type ErrType = string | Error | void | undefined;
type HandleableResult<T, E extends ErrType> = Result<T, E> & {
    handle: (handler: (error: E) => void) => Result<T, E>;
};
declare const mayFail: <T>(callback: Callback<T>) => HandleableResult<T, string>;
export { mayFail };
