import { Result } from "ts-res";
type Callback<T> = () => Promise<T>;
type ErrType = string | Error | void | undefined;
type HandleableResult<T, E extends ErrType> = {
    handle: (handler: (e: E) => void) => HandleableResult<T, E>;
    complete: () => Promise<Result<T, E>>;
};
declare const mayFailAsync: <T>(callback: Callback<T>) => HandleableResult<T, string>;
export { mayFailAsync };
