/**
 * Transaction-build error container. Carries the failed CBOR + a JSON dump
 * so failures can be inspected post-hoc by consumers like
 * `minting.handle.me`'s diagnostic logger.
 *
 * The old `mayFailTransaction` wrapper around Helios's `TxBuilder.buildUnsafe`
 * is gone — with the cardano-sdk pattern each tx builder runs coin selection
 * + `createTransactionInternals` inline and throws a plain `BuildTxError` on
 * failure, so no helper was worth keeping.
 */
declare class BuildTxError extends Error {
    code: number;
    failedTxCbor: string;
    failedTxJson: Record<string, any>;
    static from(error: Error, failedTxCbor: string, failedTxJson?: Record<string, any>): BuildTxError;
    constructor(message: string, failedTxCbor: string, failedTxJson: Record<string, any>);
}
interface TxSuccessResult {
    cborHex: string;
    txHash: string;
}
export { BuildTxError };
export type { TxSuccessResult };
