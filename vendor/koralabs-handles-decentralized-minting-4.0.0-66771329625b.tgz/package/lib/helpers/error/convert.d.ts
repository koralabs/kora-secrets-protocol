declare const convertError: (item: unknown) => string;
export default convertError;
