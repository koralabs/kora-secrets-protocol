import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
type BlockfrostNetwork = "mainnet" | "preprod" | "preview";
export interface BlockfrostBuildContext {
    protocolParameters: CardanoTypes.ProtocolParameters;
    validityInterval: CardanoTypes.ValidityInterval;
}
export interface BlockfrostBuildContextDependencies {
    fetchFn?: typeof fetch;
}
export declare const getBlockfrostBuildContext: (network: BlockfrostNetwork, apiKey: string, dependencies?: BlockfrostBuildContextDependencies) => Promise<BlockfrostBuildContext>;
export {};
