import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
export declare const projectPendingTransaction: (cborHex: string) => string;
export declare const resetProjectedLedger: () => void;
export interface FetchBlockfrostUtxosOptions {
    excludeWithReferenceScripts?: boolean;
}
export declare const fetchBlockfrostUtxos: (address: string, apiKey: string, network: "preview" | "preprod" | "mainnet", fetchFn?: typeof fetch, options?: FetchBlockfrostUtxosOptions) => Promise<CardanoTypes.Utxo[]>;
