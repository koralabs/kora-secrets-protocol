import { Buffer } from "node:buffer";
/**
 * CBOR byte-walker + witness-set splicer. Used to merge vkey signatures into
 * a pre-built Plutus transaction without disturbing the original script /
 * redeemer / datum bytes. The naive approach — decode the tx to Core, merge,
 * re-encode — produces definite-length Plutus data CBOR that the Cardano node
 * rejects with PPViewHashesDontMatch, because script_data_hash is computed
 * over the *original* indefinite-length redeemer bytes.
 *
 * Ported from handle.me/static/browser-tests/support/cborSplice.ts.
 */
/**
 * Skip a single CBOR item starting at `start` and return the byte offset
 * immediately after the item. Handles all major types and indefinite-length
 * arrays/maps. Throws on the reserved additional-info values 28-30.
 */
export declare const skipCborItem: (buf: Buffer, start: number) => number;
/**
 * Given a Conway `transaction = [body, witness_set, is_valid, aux]` CBOR
 * array starting at byte 0 with the outer array marker, return the start and
 * end offsets of the witness_set (element index 1).
 */
export declare const locateWitnessSet: (txBytes: Buffer) => {
    start: number;
    end: number;
};
/**
 * Splice a vkey-only witness_set (`sigOnlyCbor` — a map with one key=0 entry
 * produced by Serialization.TransactionWitnessSet.fromCore) into the original
 * witness_set bytes while preserving scripts / redeemers / datums
 * byte-for-byte.
 *
 * `origWsBytes` is the raw witness_set map bytes from the unsigned tx.
 * `sigOnlyCbor` is the full CBOR hex of a witness_set containing only vkeys
 * (e.g. `a10181825820...`).
 *
 * Returns a hex string of the merged witness_set map suitable to be
 * concatenated back into the outer tx CBOR array.
 *
 * Assumes definite-length map encoding for the original witness_set — which
 * matches what cardano-sdk produces for build results today.
 */
export declare const spliceVkeysIntoWitnessSet: (origWsBytes: Buffer, sigOnlyCbor: string) => string;
/**
 * Merge vkey signatures into an existing transaction CBOR hex, preserving
 * the original witness_set bytes byte-for-byte (scripts, redeemers, datums).
 *
 * `txCborHex` is the unsigned or partially signed transaction CBOR.
 * `sigOnlyCborHex` is a full witness_set CBOR containing only vkeys.
 *
 * Returns the merged transaction CBOR hex.
 */
export declare const mergeVkeysIntoTxCbor: (txCborHex: string, sigOnlyCborHex: string) => string;
