/**
 * Plutus Data JSON format accepted by `scalus.applyDataArgToScript`.
 *
 * The JSON shape is the canonical Plutus Data JSON used by the Cardano node
 * / CLI. `int` must be a JSON number — scalus's pickle JSON parser rejects
 * strings. Values larger than `Number.MAX_SAFE_INTEGER` should go through a
 * different encoding (split into constr fields or use bytes).
 */
export type PlutusDataJson = {
    int: number;
} | {
    bytes: string;
} | {
    constructor: number;
    fields: PlutusDataJson[];
} | {
    list: PlutusDataJson[];
} | {
    map: {
        k: PlutusDataJson;
        v: PlutusDataJson;
    }[];
};
/**
 * Detect whether a script-cbor hex string is in the on-chain double-CBOR
 * form (byte string of byte string of flat UPLC) or the single-CBOR form
 * Blockfrost's `/scripts/{hash}/cbor` returns. Wraps once if needed.
 * Symmetric counterpart to `plutusV2ScriptHash`'s auto-detect branch —
 * use this whenever you're about to call
 * `Serialization.PlutusV2Script.fromCbor(hex)` with CBOR from an external
 * source that might be single-wrapped.
 */
export declare const ensureDoubleCbor: (cborHex: string) => string;
/**
 * Apply one or more Plutus data arguments to a compiled Aiken validator,
 * producing a new parameterized validator as a *double*-CBOR hex string
 * suitable for direct consumption by `Serialization.PlutusV2Script.fromCbor`.
 *
 * Replaces helios's `UplcProgramV2.apply([...params])`. Scalus consumes and
 * returns double-CBOR; we wrap the blueprint's single-CBOR form once at
 * entry and emit the result unchanged.
 */
export declare const applyParamsToScript: (blueprintCompiledCodeHex: string, params: PlutusDataJson[]) => string;
/**
 * Convert a `PlutusDataJson` to the cardano-sdk Core `PlutusData` shape.
 * The Core shape is a structural union over `bigint`, `Uint8Array`, and
 * plain objects/maps/lists.
 */
export declare const plutusDataJsonToCore: (json: PlutusDataJson) => any;
/**
 * Encode a `PlutusDataJson` as a CBOR hex string, compatible with what the
 * on-chain script expects. Useful for building inline datums and redeemers.
 */
export declare const plutusDataJsonToCbor: (json: PlutusDataJson) => string;
/**
 * Compute the blake2b-224 script hash of a PlutusV2 script. Accepts either
 * the blueprint single-CBOR form or the on-chain double-CBOR form — detects
 * which and wraps if needed.
 */
export declare const plutusV2ScriptHash: (cborHex: string) => string;
/**
 * Compute the blake2b-224 script hash of a PlutusV3 script. Same CBOR handling
 * as `plutusV2ScriptHash`, but with the V3 language tag (0x03). The script hash
 * is `blake2b224(version_byte || cbor)`, so V2 vs V3 of the SAME cbor produce
 * DIFFERENT hashes. The DeMi minting contracts (demimnt/order/minting_data) are
 * genuinely PlutusV2, but cross-repo pz contracts (handles-personalization
 * persprx/perspz/persdsg/perslfc) are PlutusV3 — hash THOSE with this, not the
 * V2 helper. (Hashing the V3 persprx as V2 produced the phantom `fd517730`
 * pz_script_address; its real V3 hash is `7cf10558`.) When in doubt, prefer the
 * authoritative api script registry over recomputing a foreign contract's hash.
 */
export declare const plutusV3ScriptHash: (cborHex: string) => string;
