import "./conwayEra.js";
import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
type CostModels = Map<CardanoTypes.PlutusLanguageVersion, number[]>;
/**
 * Conway-aware replacement for `@cardano-sdk/tx-construction`'s
 * `computeScriptDataHash`.
 *
 * The upstream SDK re-serialises redeemers as an Alonzo-era CBOR **array**
 * when computing the script-data hash, even though the witness set already
 * encodes them as a Conway-era CBOR **map**. The Cardano node hashes the
 * bytes that actually appear in the witness set (map format on Conway), so
 * the two hashes diverge and every submitted tx gets rejected with
 * PPViewHashesDontMatch.
 *
 * This function builds the redeemer CBOR in MAP form directly, matching what
 * the node computes.
 *
 * Ported from handle.me/bff/lib/cardano/computeScriptDataHash.ts.
 */
export declare const computeScriptDataHash: (costModels: CostModels, usedLanguages: CardanoTypes.PlutusLanguageVersion[], redeemers?: CardanoTypes.Redeemer[], datums?: CardanoTypes.PlutusData[]) => string | undefined;
export {};
