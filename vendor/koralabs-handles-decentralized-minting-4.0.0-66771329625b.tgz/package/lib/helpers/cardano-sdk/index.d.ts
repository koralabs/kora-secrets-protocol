import "./conwayEra.js";
export declare const Cardano: typeof import("@cardano-sdk/core").Cardano;
export declare const Serialization: typeof import("@cardano-sdk/core").Serialization;
export type { Cardano as CardanoTypes } from "@cardano-sdk/core";
export type { HexBlob } from "@cardano-sdk/util";
type PaymentAddress = import("@cardano-sdk/core").Cardano.TxOut["address"];
export declare const asPaymentAddress: (address: string) => PaymentAddress;
export declare const buildPlaceholderSignatures: (signerCount: number) => Map<any, any>;
export declare const transactionToCbor: (tx: import("@cardano-sdk/core").Cardano.Tx) => string;
export declare const transactionHashFromCore: (tx: {
    body: import("@cardano-sdk/core").Cardano.TxBody;
}) => string;
export { locateWitnessSet, mergeVkeysIntoTxCbor, skipCborItem, spliceVkeysIntoWitnessSet, } from "./cborSplice.js";
export { computeScriptDataHash } from "./computeScriptDataHash.js";
export { getNetworkId, type NetworkName } from "./networkName.js";
export { applyParamsToScript, ensureDoubleCbor, type PlutusDataJson, plutusDataJsonToCbor, plutusDataJsonToCore, plutusV2ScriptHash, plutusV3ScriptHash, } from "./scriptParams.js";
