import { DotenvConfigOptions } from "dotenv";
import { Result } from "ts-res";
declare const loadEnv: (options?: DotenvConfigOptions) => void;
declare function get(key: string, type: "string"): Result<string, string>;
declare function get(key: string, type: "number"): Result<number, string>;
declare function has(key: string): boolean;
export { get, has, loadEnv };
