declare const invariant: (condition: any, message?: string | (() => string)) => asserts condition;
export { invariant };
