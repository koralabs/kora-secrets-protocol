declare const _default: {
    preamble: {
        title: string;
        description: string;
        version: string;
        plutusVersion: string;
        compiler: {
            name: string;
            version: string;
        };
        license: string;
    };
    validators: ({
        title: string;
        redeemer: {
            title: string;
            schema: {
                $ref: string;
            };
        };
        parameters: {
            title: string;
            schema: {
                $ref: string;
            };
        }[];
        compiledCode: string;
        hash: string;
        plutusVersion: string;
        datum?: undefined;
    } | {
        title: string;
        datum: {
            title: string;
            schema: {
                $ref: string;
            };
        };
        redeemer: {
            title: string;
            schema: {
                $ref: string;
            };
        };
        parameters: {
            title: string;
            schema: {
                $ref: string;
            };
        }[];
        compiledCode: string;
        hash: string;
        plutusVersion: string;
    } | {
        title: string;
        datum: {
            title: string;
            schema: {
                $ref: string;
            };
        };
        redeemer: {
            title: string;
            schema: {
                $ref: string;
            };
        };
        compiledCode: string;
        hash: string;
        plutusVersion: string;
        parameters?: undefined;
    })[];
    definitions: {
        Data: {
            title: string;
            description: string;
        };
        Int: {
            dataType: string;
        };
        ByteArray: {
            dataType: string;
        };
        "List<validations/minting_data/types/BurnProof>": {
            dataType: string;
            items: {
                $ref: string;
            };
        };
        "List<validations/minting_data/types/LabelAssetProof>": {
            dataType: string;
            items: {
                $ref: string;
            };
        };
        "List<validations/minting_data/types/LegacyHandleProof>": {
            dataType: string;
            items: {
                $ref: string;
            };
        };
        "List<validations/minting_data/types/OrderProof>": {
            dataType: string;
            items: {
                $ref: string;
            };
        };
        "Option<aiken/merkle_patricia_forestry/Proof>": {
            title: string;
            anyOf: {
                title: string;
                description: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            }[];
        };
        "Option<cardano/address/StakeCredential>": {
            title: string;
            anyOf: {
                title: string;
                description: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            }[];
        };
        "Option<decentralized_minting/discount/DiscountClaim>": {
            title: string;
            anyOf: {
                title: string;
                description: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            }[];
        };
        "aiken/crypto/ScriptHash": {
            title: string;
            dataType: string;
        };
        "aiken/crypto/VerificationKeyHash": {
            title: string;
            dataType: string;
        };
        "aiken/merkle_patricia_forestry/Neighbor": {
            title: string;
            description: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "aiken/merkle_patricia_forestry/Proof": {
            title: string;
            dataType: string;
            items: {
                $ref: string;
            };
        };
        "aiken/merkle_patricia_forestry/ProofStep": {
            title: string;
            description: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "cardano/address/Address": {
            title: string;
            description: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "cardano/address/Credential": {
            title: string;
            description: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            }[];
        };
        "cardano/address/PaymentCredential": {
            title: string;
            description: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            }[];
        };
        "cardano/address/StakeCredential": {
            title: string;
            description: string;
            anyOf: ({
                title: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            } | {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            })[];
        };
        "cardano/assets/PolicyId": {
            title: string;
            dataType: string;
        };
        "common/hashes/ScriptHash": {
            title: string;
            dataType: string;
        };
        "common/hashes/VerificationKeyHash": {
            title: string;
            dataType: string;
        };
        "decentralized_minting/discount/DiscountClaim": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "decentralized_minting/orders/OrderDatum": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "decentralized_minting/orders/OrderRedeemer": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: never[];
            }[];
        };
        "demimnt/MintV1Redeemer": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: never[];
            }[];
        };
        "demimntmpt/MintingDataRedeemer": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    $ref: string;
                }[];
            }[];
        };
        "validations/minting_data/types/BurnProof": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "validations/minting_data/types/LabelAssetProof": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "validations/minting_data/types/LegacyHandleProof": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "validations/minting_data/types/OrderProof": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
        "List<validations/minting_data/types/LabeledRootBurnProof>": {
            dataType: string;
            items: {
                $ref: string;
            };
        };
        "validations/minting_data/types/LabeledRootBurnProof": {
            title: string;
            anyOf: {
                title: string;
                dataType: string;
                index: number;
                fields: {
                    title: string;
                    $ref: string;
                }[];
            }[];
        };
    };
};
export default _default;
