import { OwnerSettings, SubHandleSettings } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const buildTierPricingData: (tierPricing: Array<Array<bigint>>) => PlutusData;
declare const buildSubHandleSettingsData: (subHandleSettings: SubHandleSettings) => PlutusData;
declare const buildOwnerSettingsData: (ownerSettings: OwnerSettings) => PlutusData;
export { buildOwnerSettingsData, buildSubHandleSettingsData, buildTierPricingData, };
