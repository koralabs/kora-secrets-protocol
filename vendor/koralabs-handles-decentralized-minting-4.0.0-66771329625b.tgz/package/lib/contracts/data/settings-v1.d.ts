import type { NetworkName } from "../../helpers/cardano-sdk/networkName.js";
import { SettingsV1 } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const buildSettingsV1Data: (settings: SettingsV1) => PlutusData;
declare const decodeSettingsV1Data: (data: PlutusData, network: NetworkName) => SettingsV1;
export { buildSettingsV1Data, decodeSettingsV1Data };
