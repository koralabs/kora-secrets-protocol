import { DiscountClaim } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const buildDiscountClaimData: (claim: DiscountClaim) => PlutusData;
type DiscountClaimInfo = {
    type: "rarity";
    handle_name: string;
} | {
    type: "og";
    handle_name: string;
} | {
    type: "partner";
    policy_id: string;
    asset_name: string;
} | {
    type: "hal";
    asset_name: string;
};
declare const decodeDiscountClaimInfo: (data: PlutusData) => DiscountClaimInfo;
export type { DiscountClaimInfo };
export { buildDiscountClaimData, decodeDiscountClaimInfo };
