import { HandlePriceData, HandlePriceInfo } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const buildHandlePriceInfoData: (handlePriceInfo: HandlePriceInfo) => PlutusData;
declare const buildHandlePriceData: (handlePriceData: HandlePriceData) => PlutusData;
declare const decodeHandlePriceInfoDatum: (datumCbor: string | undefined) => HandlePriceInfo;
export { buildHandlePriceData, buildHandlePriceInfoData, decodeHandlePriceInfoDatum, };
