import { Settings } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const buildSettingsData: (settings: Settings) => PlutusData;
declare const decodeSettingsDatum: (datumCbor: string | undefined) => Settings;
export { buildSettingsData, decodeSettingsDatum };
