import { PlutusData } from "./plutusData.js";
declare const buildMintV1MintHandlesRedeemer: () => PlutusData;
declare const buildMintV1BurnHandlesRedeemer: () => PlutusData;
export { buildMintV1BurnHandlesRedeemer, buildMintV1MintHandlesRedeemer };
