import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
/**
 * Canonical Plutus data representation used throughout the package —
 * re-exports `@cardano-sdk/core`'s `Cardano.PlutusData` Core shape:
 *
 *   bigint                                             - integer
 *   Uint8Array                                         - byte string
 *   { items: PlutusData[] }                            - list
 *   { data: Map<PlutusData, PlutusData> }              - map
 *   { constructor: bigint, fields: PlutusList }        - constr
 */
export type PlutusData = CardanoTypes.PlutusData;
export type PlutusList = CardanoTypes.PlutusList;
export declare const mkInt: (value: bigint | number) => PlutusData;
export declare const mkBytes: (hex: string) => PlutusData;
export declare const mkList: (items: PlutusData[]) => PlutusData;
export declare const mkMap: (entries: Array<[PlutusData, PlutusData]>) => PlutusData;
export declare const mkConstr: (tag: number | bigint, fields: PlutusData[]) => PlutusData;
export declare const plutusDataToCbor: (data: PlutusData) => string;
export declare const plutusDataFromCbor: (cbor: string) => PlutusData;
export declare const isBytes: (data: PlutusData) => data is Uint8Array;
export declare const isList: (data: PlutusData) => data is CardanoTypes.PlutusList;
export declare const isMap: (data: PlutusData) => data is CardanoTypes.PlutusMap;
export declare const isConstr: (data: PlutusData) => data is CardanoTypes.ConstrPlutusData;
export declare const expectConstr: (data: PlutusData, tag?: number, fieldCount?: number, label?: string) => CardanoTypes.ConstrPlutusData;
export declare const expectInt: (data: PlutusData, label?: string) => bigint;
export declare const expectBytesHex: (data: PlutusData, label?: string) => string;
export declare const expectList: (data: PlutusData, label?: string) => PlutusData[];
export declare const mkBool: (value: boolean) => PlutusData;
/** Unit / Void — constr tag 0, no fields. CBOR: d87980. */
export declare const mkUnit: () => PlutusData;
/** Wrap data in a Plutus V1 redeemer wrapper: `Constr 1 [inner]`. */
export declare const mkRedeemerWrapper: (inner: PlutusData) => PlutusData;
/**
 * Build the Plutus `Credential` data shape:
 *   PubKeyCredential Bytes    = Constr 0 [Bytes]
 *   ScriptCredential Bytes    = Constr 1 [Bytes]
 */
export declare const buildCredentialData: (credential: CardanoTypes.Credential) => PlutusData;
/**
 * Build the Plutus `Option<StakingCredential>` data shape:
 *   None                               = Constr 1 []
 *   Some (StakingHash credential)      = Constr 0 [Constr 0 [credential]]
 */
export declare const buildOptionalStakingCredentialData: (stakingCredential?: CardanoTypes.Credential) => PlutusData;
/**
 * Build the Plutus `Address` data shape for a Cardano base/enterprise
 * address.
 *
 *   Address = Constr 0 [Credential, Option<StakingCredential>]
 */
export declare const buildAddressData: (addressBech32: string) => PlutusData;
/**
 * Decode a Plutus `Credential` back to the cardano-sdk Core shape.
 */
export declare const decodeCredentialFromData: (data: PlutusData) => CardanoTypes.Credential;
export declare const decodeOptionalStakingCredentialFromData: (data: PlutusData) => CardanoTypes.Credential | undefined;
/**
 * Decode a Plutus address to bech32. Requires the `network` because the
 * Plutus address is agnostic to mainnet vs testnet.
 */
export declare const decodeAddressFromData: (data: PlutusData, network: "mainnet" | "preprod" | "preview") => string;
