import { PlutusData } from "./plutusData.js";
/** Native-script-style signature multisig: `Constr 0 [PubKeyHash]`. */
declare const makeSignatureMultiSigScriptData: (pubKeyHashHex: string) => PlutusData;
export { makeSignatureMultiSigScriptData };
