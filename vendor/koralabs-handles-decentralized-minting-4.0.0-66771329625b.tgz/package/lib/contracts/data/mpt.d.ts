import { MPTProof, MPTProofStep, Neighbor } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const buildMPTProofData: (proof: MPTProof) => PlutusData;
declare const buildMPTProofStepData: (proofStep: MPTProofStep) => PlutusData;
declare const buildNeighborData: (neighbor: Neighbor) => PlutusData;
export { buildMPTProofData, buildMPTProofStepData, buildNeighborData };
