import type { NetworkName } from "../../helpers/cardano-sdk/networkName.js";
import { OrderDatum } from "../types/index.js";
import { PlutusData } from "./plutusData.js";
declare const decodeOrderDatum: (datumCbor: string | undefined, network: NetworkName) => OrderDatum;
declare const buildOrderData: (order: OrderDatum) => PlutusData;
declare const buildOrderExecuteRedeemer: () => PlutusData;
declare const buildOrderCancelRedeemer: () => PlutusData;
declare const buildOrderRefundRedeemer: () => PlutusData;
export { buildOrderCancelRedeemer, buildOrderData, buildOrderExecuteRedeemer, buildOrderRefundRedeemer, decodeOrderDatum, };
