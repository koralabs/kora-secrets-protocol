/** Plutus language version a validator was compiled with. */
export type BlueprintPlutusVersion = "v2" | "v3";
/**
 * A parameterized validator as consumed by the rest of the package.
 *
 * `optimizedCbor` / `unoptimizedCbor` are in double-CBOR form (byte string
 * wrapping byte string wrapping flat UPLC) — the format that
 * `Serialization.PlutusVxScript.fromCbor` and the on-chain `script_ref` field
 * both expect.
 *
 * `plutusVersion` is carried per-validator because the DeMi engine now mixes
 * versions: the three non-proxy validators (demimnt/demimntmpt/demiord) are
 * Plutus V3 (aiken v1.1.22), while the frozen mint proxy (demimntprx) stays
 * Plutus V2 (aiken v1.0.29-alpha). The hash differs by language tag, so the
 * correct version must be applied when wrapping/hashing each script.
 */
export interface AppliedPlutusScript {
    optimizedCbor: string;
    unoptimizedCbor: string;
    scriptHash: string;
    plutusVersion: BlueprintPlutusVersion;
}
/**
 * @deprecated Historical name from when every DeMi validator was Plutus V2.
 * Kept as an alias so existing references compile; new code should use
 * `AppliedPlutusScript` and consult `plutusVersion`.
 */
export type AppliedPlutusV2Script = AppliedPlutusScript;
export declare const getMintProxyMintValidator: (mint_version: bigint) => AppliedPlutusScript;
export declare const getMintV1WithdrawValidator: (minting_data_script_hash: string) => AppliedPlutusScript;
export declare const getMintingDataSpendValidator: (legacy_policy_id: string, admin_verification_key_hash: string, anchor_slot: number, anchor_time_ms: number, slot_length_ms: number) => AppliedPlutusScript;
export declare const getOrdersSpendValidator: () => AppliedPlutusScript;
