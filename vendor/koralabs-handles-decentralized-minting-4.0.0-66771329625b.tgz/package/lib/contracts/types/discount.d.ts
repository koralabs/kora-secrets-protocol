import type { MPTProof } from "./mpt.js";
type DiscountClaim = {
    type: "rarity";
    handle_name: string;
} | {
    type: "og";
    handle_name: string;
} | {
    type: "partner";
    policy_id: string;
    asset_name: string;
    value: string;
    proof: MPTProof;
} | {
    type: "hal";
    asset_name: string;
};
export type { DiscountClaim };
