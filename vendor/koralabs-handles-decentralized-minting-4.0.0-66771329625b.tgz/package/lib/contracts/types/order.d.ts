import type { PlutusData } from "../data/plutusData.js";
interface OrderDatum {
    owner: PlutusData;
    requested_handle: string;
    destination_address: string;
    discount_claim?: PlutusData;
    is_virtual: bigint;
}
export type { OrderDatum };
