interface SettingsV1 {
    policy_id: string;
    allowed_minters: string[];
    valid_handle_price_assets: string[];
    treasury_address: string;
    treasury_fee_percentage: bigint;
    pz_script_address: string;
    order_script_hash: string;
    minting_data_script_hash: string;
    discount_config: DiscountConfig;
    sub_handle_minter_fee: bigint;
    sub_handle_treasury_fee: bigint;
}
interface DiscountConfig {
    partner_nft_bps: bigint;
    hal_bps: bigint;
    og_bps: bigint;
    legendary_bps: bigint;
    ultra_rare_bps: bigint;
    rare_bps: bigint;
    free_virtual_count: bigint;
    hal_policy_id: string;
}
export type { DiscountConfig, SettingsV1 };
