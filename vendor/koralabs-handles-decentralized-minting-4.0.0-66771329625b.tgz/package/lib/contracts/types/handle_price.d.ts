type HandlePriceData = bigint[];
type HandlePriceInfo = {
    current_data: HandlePriceData;
    prev_data: HandlePriceData;
    updated_at: bigint;
};
type HandlePrices = {
    basic: number;
    common: number;
    rare: number;
    ultraRare: number;
};
declare const convertHandlePricesToHandlePriceData: (handlePrices: HandlePrices) => HandlePriceData;
declare const convertHandlePriceDataToHandlePrices: (handlePriceData: HandlePriceData) => HandlePrices;
export type { HandlePriceData, HandlePriceInfo, HandlePrices };
export { convertHandlePriceDataToHandlePrices, convertHandlePricesToHandlePriceData, };
