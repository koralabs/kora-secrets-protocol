import type { PlutusData } from "../data/plutusData.js";
interface Settings {
    mint_governor: string;
    mint_version: bigint;
    data: PlutusData;
}
export type { Settings };
