import { MPTProof } from "./mpt.js";
interface MintingData {
    mpt_root_hash: string;
}
type OrderProof = {
    mpt_proof: MPTProof;
};
type BurnProof = {
    mpt_proof: MPTProof;
    handle_name: string;
    is_virtual: bigint;
    root_absence?: MPTProof;
};
type LegacyHandleProof = {
    mpt_proof: MPTProof;
    handle_name: string;
    is_virtual: bigint;
};
type LabelAssetProof = {
    mpt_proof: MPTProof;
    handle_name: string;
    label: string;
    old_labels: string;
    amount: bigint;
};
type LabeledRootBurnProof = {
    mpt_proof: MPTProof;
    handle_name: string;
    labels: string;
};
export type { BurnProof, LabelAssetProof, LabeledRootBurnProof, LegacyHandleProof, MintingData, OrderProof, };
