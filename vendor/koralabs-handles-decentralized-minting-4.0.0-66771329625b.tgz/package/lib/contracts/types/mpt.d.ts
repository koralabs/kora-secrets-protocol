type MPTProof = MPTProofStep[];
type MPTProofStep = BranchProofStep | ForkProofStep | LeafProofStep;
interface BranchProofStep {
    type: "branch";
    skip: number;
    neighbors: string;
}
interface ForkProofStep {
    type: "fork";
    skip: number;
    neighbor: Neighbor;
}
interface LeafProofStep {
    type: "leaf";
    skip: number;
    key: string;
    value: string;
}
interface Neighbor {
    nibble: number;
    prefix: string;
    root: string;
}
declare const parseMPTProofJSON: (jsonObject: object) => MPTProof;
declare const parseMPTProofStepJSON: (jsonObject: object) => MPTProofStep;
export type { MPTProof, MPTProofStep, Neighbor };
export { parseMPTProofJSON, parseMPTProofStepJSON };
