import type { Cardano as CardanoTypes } from "@cardano-sdk/core";
import type { HexBlob } from "../helpers/cardano-sdk/index.js";
import { type NetworkName } from "../helpers/cardano-sdk/index.js";
import type { AppliedPlutusV2Script } from "./validators.js";
/**
 * Contract build inputs, previously typed via `@helios-lang/tx-utils`. The
 * local `NetworkName` union and cardano-sdk primitives cover the same
 * information without the Helios dependency tree.
 */
interface BuildContractsParams {
    network: NetworkName;
    mint_version: bigint;
    legacy_policy_id: string;
    admin_verification_key_hash: string;
}
/**
 * All contract hashes/addresses a tx builder in this package might need.
 * Every field is either a hex string or a bech32 string — no Helios types.
 */
export interface BuiltContracts {
    mintProxy: {
        validator: AppliedPlutusV2Script;
        policyId: string;
    };
    mintingData: {
        validator: AppliedPlutusV2Script;
        validatorHash: string;
        scriptAddress: string;
    };
    mintV1: {
        validator: AppliedPlutusV2Script;
        validatorHash: string;
        stakingAddress: string;
        registrationCertificate: CardanoTypes.StakeAddressCertificate;
    };
    orders: {
        validator: AppliedPlutusV2Script;
        validatorHash: string;
        scriptAddress: string;
    };
    handlePolicyId: string;
}
export declare const getSlotAnchor: (network: string) => {
    anchor_slot: number;
    anchor_time_ms: number;
    slot_length_ms: number;
};
declare const buildContracts: (params: BuildContractsParams) => BuiltContracts;
export type { HexBlob };
export type { BuildContractsParams };
export { buildContracts };
