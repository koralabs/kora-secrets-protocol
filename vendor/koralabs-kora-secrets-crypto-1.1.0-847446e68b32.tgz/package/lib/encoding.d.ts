import { type SecretType } from './constants.ts';
/** Canonical, ready-to-split representation of a user secret plus bundle metadata. */
export interface EncodedSecret {
    type: SecretType;
    /** How `secret_bytes` was derived from the input (informational; drives recovery UX). */
    encoding: 'raw' | 'utf8' | 'jcs';
    /** Bytes fed to Shamir splitting. */
    secret_bytes: Uint8Array;
    /** Recorded in bundle metadata (crypto.md `secret.bytes_len`). */
    bytes_len: number;
}
export type EncodeSecretInput = {
    type: 'bip39_entropy';
    input: string;
} | {
    type: 'utf8_text';
    input: string;
} | {
    type: 'json_jcs';
    input: string | unknown;
} | {
    type: 'opaque_bytes';
    input: Uint8Array;
};
/**
 * Convert a supported secret type into canonical `secret_bytes` + `bytes_len`, enforcing the
 * 64 KiB size bound *before* anything else cryptographic happens (crypto.md "Secret size
 * limits"). Never normalizes text — `utf8_text` is the exact bytes as entered.
 */
export declare function encodeSecret(args: EncodeSecretInput): EncodedSecret;
/**
 * Inverse of {@link encodeSecret} for recovery UX: turn reconstructed `secret_bytes` back into
 * what the user originally entered. bip39 entropy round-trips through the English wordlist to the
 * mnemonic; text/JCS decode as UTF-8; opaque bytes present as hex (callers handle raw downloads).
 */
export declare function presentSecret(bytes: Uint8Array, type: SecretType): string;
//# sourceMappingURL=encoding.d.ts.map