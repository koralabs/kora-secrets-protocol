export declare const SsrErrorCode: {
    readonly SecretEmpty: "SECRET_EMPTY";
    readonly SecretTooLarge: "SECRET_TOO_LARGE";
    readonly InvalidMnemonic: "INVALID_MNEMONIC";
    readonly InvalidEntropyLength: "INVALID_ENTROPY_LENGTH";
    readonly InvalidJson: "INVALID_JSON";
    readonly InvalidInputType: "INVALID_INPUT_TYPE";
    readonly UnknownSecretType: "UNKNOWN_SECRET_TYPE";
    readonly InvalidThreshold: "INVALID_THRESHOLD";
    readonly InvalidShareCount: "INVALID_SHARE_COUNT";
    readonly InvalidShareIndex: "INVALID_SHARE_INDEX";
    readonly InvalidKeyLength: "INVALID_KEY_LENGTH";
    readonly DecryptionFailed: "DECRYPTION_FAILED";
    readonly InvalidBundle: "INVALID_BUNDLE";
    readonly BundleHashMismatch: "BUNDLE_HASH_MISMATCH";
    readonly ProofHashMismatch: "PROOF_HASH_MISMATCH";
    readonly ProfileUnresolvable: "PROFILE_UNRESOLVABLE";
    readonly ChainMismatch: "CHAIN_MISMATCH";
    readonly NetworkMismatch: "NETWORK_MISMATCH";
    readonly InvalidArtifact: "INVALID_ARTIFACT";
    readonly SessionMismatch: "SESSION_MISMATCH";
};
export type SsrErrorCode = (typeof SsrErrorCode)[keyof typeof SsrErrorCode];
export declare class SsrError extends Error {
    readonly code: SsrErrorCode;
    constructor(code: SsrErrorCode, message: string);
}
export declare function isSsrError(err: unknown, code?: SsrErrorCode): err is SsrError;
//# sourceMappingURL=errors.d.ts.map