import { type SealRng } from './aead-ecdh.ts';
/** A fresh per-recovery-attempt encryption keypair plus the session identifier. */
export interface RecoverySession {
    recovery_pub: Uint8Array;
    recovery_priv: Uint8Array;
    /** Opaque session identifier (hex). In production this is the seed-UTxO-derived value from
     *  the on-chain request (onchain.md); a random id is generated when none is supplied (e.g.
     *  the chain-free crypto pipeline test). */
    session_id: string;
}
/** Binds a re-encrypted share to its recovery session + guardian. */
export interface SessionBinding {
    policy_id: string;
    session_id: string;
    guardian_id: string;
}
/** The re-encrypted share artifact published by a guardian (crypto.md schema). */
export interface ReencryptedShareArtifact {
    version: number;
    policy_id: string;
    session_id: string;
    guardian_asset_id: string;
    sender_ephemeral_pub_b64: string;
    nonce_b64: string;
    ciphertext_b64: string;
}
/** Generate a fresh recovery session. Pass `session_id` to bind to an on-chain-derived id. */
export declare function newRecoverySession(opts?: {
    session_id?: string;
}): RecoverySession;
/**
 * Re-encrypt a guardian's decrypted share to the requester's recovery session public key,
 * producing the publishable artifact. Same sealed-box scheme as share encryption, domain-
 * separated to the session context.
 */
export declare function reencryptShareToSession(sharePlain: Uint8Array, recoveryPub: Uint8Array, binding: SessionBinding, rng?: SealRng): ReencryptedShareArtifact;
/**
 * Validate the shape of a re-encrypted share artifact, returning a typed object. Throws
 * {@link SsrError} INVALID_ARTIFACT for any structural problem (wrong version, missing
 * fields, undecodable base64).
 */
export declare function parseShareArtifact(value: unknown): ReencryptedShareArtifact;
/**
 * Decrypt a re-encrypted share artifact with the recovery session private key. The binding
 * is taken from the artifact itself, so a wrong session key (a different recovery attempt) or
 * any tampering of policy_id/session_id/guardian fails authentication — the replay/confusion
 * guard required by the spec.
 */
export declare function decryptSessionShare(artifact: ReencryptedShareArtifact, recoveryPriv: Uint8Array): Uint8Array;
//# sourceMappingURL=reencryption.d.ts.map