/**
 * One Shamir share. `index` is the SSR-domain position (1..N) used to map a share to a
 * guardian/share slot in the bundle; it is independent of the GF(256) x-coordinate the
 * underlying library embeds in `data`. `data` is self-describing (leading scheme byte).
 */
export interface SssShare {
    index: number;
    data: Uint8Array;
}
export interface SplitParams {
    m: number;
    n: number;
}
/**
 * Split `secretBytes` into N shares such that any M reconstruct it (M-of-N). Enforces
 * `n >= 1` and `1 <= m <= n`. Randomized by design (the library uses a CSPRNG for the
 * polynomial coefficients), so output is intentionally non-deterministic across calls.
 */
export declare function splitSecret(secretBytes: Uint8Array, params: SplitParams): Promise<SssShare[]>;
/**
 * Reconstruct a secret from shares. For SCHEME_DIRECT (threshold 1) any single share yields
 * the secret. For SCHEME_GF256 the share bodies are handed to the library's combine, which
 * needs at least M of them (fewer returns unrelated bytes — caller enforces M via the policy
 * threshold). Mixed schemes or an unknown tag are rejected.
 */
export declare function combineShares(shares: ReadonlyArray<SssShare | Uint8Array>): Promise<Uint8Array>;
//# sourceMappingURL=sss.d.ts.map