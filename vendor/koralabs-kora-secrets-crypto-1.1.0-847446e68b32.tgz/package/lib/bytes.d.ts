import { bytesToHex, concatBytes, hexToBytes, utf8ToBytes } from '@noble/hashes/utils';
export { bytesToHex, concatBytes, hexToBytes, utf8ToBytes };
/** RFC 8785 JSON Canonicalization Scheme. Returns undefined for non-JSON-representable values. */
export declare function canonicalJson(value: unknown): string | undefined;
/** Standard RFC 4648 base64 (with padding, no newlines), isomorphic across browser + node. */
export declare function toBase64(bytes: Uint8Array): string;
export declare function fromBase64(text: string): Uint8Array;
/** blake2b-256 (32-byte digest), the SSR integrity/fingerprint hash. */
export declare function blake2b256(data: Uint8Array): Uint8Array;
/** 32-bit unsigned big-endian encoding of a non-negative integer. */
export declare function u32be(n: number): Uint8Array;
/**
 * Unambiguous framing of a sequence of byte/string/number components for use as KDF salt or
 * AEAD AAD input. Each component is length-prefixed (u32be) so that variable-length
 * identifiers cannot be split differently to collide — e.g. ("ab","c") and ("a","bc") would
 * concatenate identically without framing, but produce different framed bytes.
 */
export declare function frame(components: ReadonlyArray<Uint8Array | string | number>): Uint8Array;
/** Constant-time-ish byte equality (length check is non-secret; content compare is fixed-cost). */
export declare function bytesEqual(a: Uint8Array, b: Uint8Array): boolean;
//# sourceMappingURL=bytes.d.ts.map