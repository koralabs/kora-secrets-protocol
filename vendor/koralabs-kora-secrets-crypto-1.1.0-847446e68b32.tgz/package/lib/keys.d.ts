/** An X25519 keypair (raw 32-byte keys). */
export interface X25519Keypair {
    priv: Uint8Array;
    pub: Uint8Array;
}
/**
 * Generate a fresh X25519 keypair using the platform CSPRNG. Used for a guardian's encryption
 * key (GEK) and for recovery-session keys. The platform MUST NOT custody the private key.
 */
export declare function newX25519Keypair(): X25519Keypair;
/** Derive the X25519 public key for a given private key (e.g. re-deriving from a stored key). */
export declare function x25519PublicKey(priv: Uint8Array): Uint8Array;
//# sourceMappingURL=keys.d.ts.map