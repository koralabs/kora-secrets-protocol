import { type Network, type SecretType } from './constants.ts';
import type { EncryptedShare } from './share-encryption.ts';
export interface BundleGuardian {
    type: 'handle' | 'token';
    asset_id: string;
    share_index: number;
}
export interface BundleSecretMeta {
    type: SecretType;
    encoding: 'raw' | 'utf8' | 'jcs';
    bytes_len: number;
}
/** One encrypted-share entry as it appears in the bundle JSON (binary fields base64). */
export interface BundleShareJson {
    guardian_asset_id: string;
    share_index: number;
    sender_ephemeral_pub_b64: string;
    nonce_b64: string;
    ciphertext_b64: string;
}
export interface BundlePolicy {
    owner_handle_asset_id: string;
    guardians: BundleGuardian[];
    threshold_m: number;
    shares_n: number;
    timelock_seconds: number;
}
/** The versioned encrypted bundle (crypto.md "Bundle JSON (v1)"), plus the bound `bundle_id`. */
export interface Bundle {
    version: number;
    network: Network;
    /** Per-bundle random id (hex), bound into each share's AEAD AAD (see share-encryption.ts). */
    bundle_id: string;
    policy: BundlePolicy;
    secret: BundleSecretMeta;
    shares: BundleShareJson[];
    integrity: {
        bundle_hash_blake2b256_hex: string;
    };
}
export type BundleWithoutIntegrity = Omit<Bundle, 'integrity'>;
export interface BuildBundleArgs {
    network: Network;
    bundle_id: Uint8Array;
    policy: BundlePolicy;
    secret: BundleSecretMeta;
    shares: Array<{
        guardian_asset_id: string;
        share_index: number;
    } & EncryptedShare>;
}
/**
 * Compute the canonical integrity hash of a bundle. The **entire `integrity` object is
 * omitted** (not blanked) before RFC 8785 JCS canonicalization + blake2b-256, yielding one
 * unambiguous canonical form (crypto.md "Bundle Hashing", decided rule).
 */
export declare function computeBundleHashHex(bundle: BundleWithoutIntegrity | Bundle): string;
/** Assemble a v1 bundle from encrypted shares + metadata and attach its integrity hash. */
export declare function buildBundle(args: BuildBundleArgs): Bundle;
/** True iff the bundle's attached integrity hash matches a fresh recomputation. */
export declare function verifyBundleHash(bundle: Bundle): boolean;
/** Throw {@link SsrError} BUNDLE_HASH_MISMATCH unless the bundle's integrity hash verifies. */
export declare function assertBundleHash(bundle: Bundle): void;
/** Decode one bundle share's binary fields back to bytes for decryption. */
export declare function decodeBundleShare(share: BundleShareJson): EncryptedShare;
//# sourceMappingURL=bundle.d.ts.map