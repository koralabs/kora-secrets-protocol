/**
 * One audited sealed-box construction shared by every SSR ciphertext: X25519 ECDH against a
 * fresh ephemeral key -> HKDF-SHA256 (caller supplies salt/info for domain separation) ->
 * AES-256-GCM with caller-supplied AAD. Used for both per-guardian share encryption (to
 * gek_pub) and recovery-session re-encryption (to recovery_pub).
 */
export interface SealedBox {
    sender_ephemeral_pub: Uint8Array;
    nonce: Uint8Array;
    ciphertext: Uint8Array;
}
export interface SealParams {
    recipient_pub: Uint8Array;
    plaintext: Uint8Array;
    salt: Uint8Array;
    info: Uint8Array | string;
    aad: Uint8Array;
}
export interface OpenParams {
    recipient_priv: Uint8Array;
    box: SealedBox;
    salt: Uint8Array;
    info: Uint8Array | string;
    aad: Uint8Array;
}
/** Injectable randomness boundary, so known-answer vectors can pin a deterministic output. */
export interface SealRng {
    ephemeral_priv?: Uint8Array;
    nonce?: Uint8Array;
}
export declare function seal(p: SealParams, rng?: SealRng): SealedBox;
export declare function open(p: OpenParams): Uint8Array;
//# sourceMappingURL=aead-ecdh.d.ts.map